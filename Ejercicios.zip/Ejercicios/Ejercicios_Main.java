package Ejercicios;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Ejercicios_Main {

	public static void main(String[] args) {
Scanner teclado = new Scanner(System.in);
		int eleccion;
		String ruta;
		String nueva;
do {
		System.out.println("Selecicione un numero :");
		System.out.println(" 1 - Obtener la información del archivo \n 2 - Crear carpetas \n 3 - Crear fichero \n 4 - Eliminar archivos o carpetas \n 5 - Renombrar Carpetas o archivos \n 6 - Salir");
		eleccion = teclado.nextInt();
		
		

switch (eleccion) {
case 1:
	 System.out.println("Ingresa la ruta del archivo o carpeta:");
     ruta = teclado.next();
     obtenerInformacion(ruta);
     
	break;
case 2:
	  System.out.println("Ingresa la ruta donde crear la carpeta:");
      ruta = teclado.next();
      crearCarpeta(ruta);
	break;
case 3:
	System.out.println("Ingresa la ruta donde crear la archivo:");
    ruta = teclado.next();
    crearArchivo(ruta);
	break;
case 4:
	System.out.println("Ingresa la ruta del archivo o carpeta  a borrar");
	ruta = teclado.next();
	eliminar(ruta);
	break;
case 5: 
	 System.out.println("Ingrese la ruta del archivo o carpeta a renombrar:");
     ruta = teclado.next();
     System.out.println("Ingrese la nueva ruta/nombre:");
     nueva = teclado.next();
     renombrar(ruta, nueva);
     break;
case 6: 
	System.out.println("Saliendo del pograma... \nAdios buenos dias");
	break;
default:
	System.out.println("Selecciona un numero dentro del menu de numeros");
break;
}
		}while(eleccion != 6);
	}

 
public static void obtenerInformacion(String ruta) {
    File cosa = new File(ruta);
    if (cosa.exists()) {
        System.out.println("Nombre: " + cosa.getName());
        System.out.println("Ruta: " + cosa.getAbsolutePath());
        if (cosa.isHidden()) {
            System.out.println("Es oculto: Sí");
        } else {
            System.out.println("Es oculto: No");
        }
        if (cosa.isDirectory()) {
            System.out.println("Tipo: Directorio");
            System.out.println("Número de elementos: " + cosa.list().length);
        } else {
            System.out.println("Tipo: Archivo");
            System.out.println("Tamaño: " + cosa.length() + " bytes");
        }
    } else {
        System.out.println("El archivo o directorio no existe.");
    }
}
public static void crearCarpeta(String ruta) {
    File carpeta = new File(ruta);
    
    if (carpeta.exists()) {
        System.out.println("La carpeta ya existe.");
    } else {
        
        if (carpeta.mkdirs()) { 
            System.out.println("Carpeta creada.");
        } else {
            System.out.println("No se pudo crear la carpeta.");
        }
    }
}
public static void crearArchivo(String ruta) {
    File archivo = new File(ruta);
   
    try {
        if (archivo.createNewFile()) {
            System.out.println("Archivo creado exitosamente.");
        } else {
            System.out.println("No se pudo crear el archivo.");
        }
    } catch (IOException e) {
        System.out.println("Error al crear el archivo: " + e.getMessage());
    }
}
public static void eliminar(String ruta) {
    File cosa = new File(ruta);
    if (cosa.delete()) {
        System.out.println("Archivo o carpeta eliminado correctamente.");
    } else {
        System.out.println("No se pudo eliminar el archivo o carpeta.");
    }
}
public static void renombrar(String ruta , String nueva) {
	  File archivoAntiguo = new File(ruta);
      File archivoNuevo = new File(nueva);
      if (archivoAntiguo.renameTo(archivoNuevo)) {
          System.out.println("Archivo o carpeta renombrado correctamente.");
      } else {
          System.out.println("No se pudo renombrar el archivo o carpeta.");
      }
  
}


}

