package Entregable;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class Controlador {
    private Modelo modelo;
    private Vista vista;

    public Controlador(Modelo modelo, Vista vista) {
        this.modelo = modelo;
        this.vista = vista;

        vista.getBtnBuscar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String palabra = vista.getTextFieldBuscar().getText(); 
                if (!palabra.isEmpty()) {
                    int veces = modelo.buscarPalabra(palabra);
                    JOptionPane.showMessageDialog(null, "La palabra aparece " + veces + " veces.");
                } else {
                    JOptionPane.showMessageDialog(null, "Introduce una palabra.");
                }
            }
        });

        vista.getBtnReemplazar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String palabraBuscar = vista.getTextFieldBuscar().getText();
                String palabraReemplazar = vista.getTextFieldReemplazar().getText();
                if (!palabraBuscar.isEmpty() && !palabraReemplazar.isEmpty()) {
                    String textoModificado = modelo.reemplazarPalabra(palabraBuscar, palabraReemplazar); 
                    vista.getTextAreaModificado().setText(textoModificado); 
                } else {
                    JOptionPane.showMessageDialog(null, "Introduce ambas palabras.");
                }
            }
        });
    }
}
