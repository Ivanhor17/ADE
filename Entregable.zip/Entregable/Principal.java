package Entregable;

import java.io.IOException;

public class Principal {

	public static void main(String[] args) {

		        Modelo modelo = new Modelo();
		        Vista vista = new Vista();
		        Controlador controlador = new Controlador(modelo, vista);
		        try {
		            String contenido = modelo.cargarArchivo("archivo.txt");
		            vista.getTextAreaOriginal().setText(contenido); 
		        } catch (IOException e) {
		            System.out.println("Error al cargar el archivo: " + e.getMessage());
		        }
		    }
		}

		

	

