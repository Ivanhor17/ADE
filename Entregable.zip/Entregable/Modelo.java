package Entregable;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Modelo {
    private String texto;

    public String cargarArchivo(String ruta) throws IOException {
        texto = new String(Files.readAllBytes(Paths.get(ruta))); 
        return texto;
    }

    public int buscarPalabra(String palabra) {
        if (texto == null) return 0; 
        return texto.split(palabra, -1).length - 1;
    }

    public String reemplazarPalabra(String palabraVieja, String palabraNueva) {
        if (texto != null) {
            texto = texto.replace(palabraVieja, palabraNueva); 
        }
        return texto;
    }
}

