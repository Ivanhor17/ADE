package javafxapplication3;

public class Futbolista {
    private int ID;
    private String nombre;
    private String posicion;
    private int año;
    private String equipo;

    public Futbolista() {
        // Constructor vacío
    }

    public Futbolista(int ID, String nombre, String posicion, int año, String equipo) {
        this.ID = ID;
        this.nombre = nombre;
        this.posicion = posicion;
        this.año = año;
        this.equipo = equipo;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }
}
