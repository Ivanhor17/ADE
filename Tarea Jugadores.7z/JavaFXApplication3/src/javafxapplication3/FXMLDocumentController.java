package javafxapplication3;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

public class FXMLDocumentController implements Initializable {

    @FXML
    private TextField fieldID;
    @FXML
    private TextField fieldName;
    @FXML
    private TextField fieldEquipo;
    @FXML
    private TextField fieldPosicion;

    private List<Futbolista> futbolistas = new ArrayList<>();
    private int currentIndex = 0; // Índice del jugador actual

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Leer el archivo XML al iniciar
        leerXML("Jugadores.xml");

        // Mostrar el primer jugador
        if (!futbolistas.isEmpty()) {
            mostrarDatos(futbolistas.get(currentIndex));
        }
    }

    private void leerXML(String archivo) {
        try {
            File file = new File(archivo);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(file);
            document.getDocumentElement().normalize();

            NodeList nodeList = document.getElementsByTagName("jugador");

            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);

                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element elemento = (Element) node;

                    int id = Integer.parseInt(elemento.getAttribute("id"));
                    String equipo = elemento.getElementsByTagName("Equipo").item(0).getTextContent();
                    String nombre = elemento.getElementsByTagName("Nombre").item(0).getTextContent();
                    String posicion = elemento.getElementsByTagName("Posicion").item(0).getTextContent();

                    Futbolista futbolista = new Futbolista(id, nombre, posicion, 0, equipo);
                    futbolistas.add(futbolista);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void mostrarDatos(Futbolista jugador) {
        if (jugador != null) {
            fieldID.setText(String.valueOf(jugador.getID()));
            fieldName.setText(jugador.getNombre());
            fieldEquipo.setText(jugador.getEquipo());
            fieldPosicion.setText(jugador.getPosicion());
        } else {
            fieldID.clear();
            fieldName.clear();
            fieldEquipo.clear();
            fieldPosicion.clear();
        }
    }

    @FXML
    private void handlePrevio(ActionEvent event) {
        if (currentIndex > 0) {
            currentIndex--;
            mostrarDatos(futbolistas.get(currentIndex));
        }
    }

    @FXML
    private void handleSiguiente(ActionEvent event) {
        if (currentIndex < futbolistas.size() - 1) {
            currentIndex++;
            mostrarDatos(futbolistas.get(currentIndex));
        }
    }
}
